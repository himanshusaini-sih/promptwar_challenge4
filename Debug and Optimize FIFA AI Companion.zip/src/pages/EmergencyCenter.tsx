import { useState } from 'react'
import { AlertTriangle, Phone, Shield, Activity, Clock } from 'lucide-react'
import PageLayout from '../components/PageLayout'

const INCIDENTS = [
  { id: 'E-014', type: 'Medical', desc: 'Fan collapse – Section B, Row 24', severity: 'critical', time: '2m ago', status: 'responding', responder: 'Medical Team Alpha' },
  { id: 'E-013', type: 'Security', desc: 'Unauthorized field access attempt – Gate 3', severity: 'high', time: '8m ago', status: 'contained', responder: 'Security Unit B' },
  { id: 'E-012', type: 'Fire', desc: 'Smoke detected – Concession Stand 7', severity: 'medium', time: '25m ago', status: 'resolved', responder: 'Fire Team 2' },
  { id: 'E-011', type: 'Medical', desc: 'Heatstroke – South Concourse', severity: 'medium', time: '41m ago', status: 'resolved', responder: 'Medical Team Beta' },
]

const CONTACTS = [
  { name: 'Emergency Operations', number: '+974-500-0001', available: true },
  { name: 'Medical Director', number: '+974-500-0012', available: true },
  { name: 'Fire Safety Chief', number: '+974-500-0018', available: false },
  { name: 'Security Commander', number: '+974-500-0025', available: true },
  { name: 'Stadium Manager', number: '+974-500-0030', available: true },
]

export default function EmergencyCenter() {
  const [alertActive, setAlertActive] = useState(false)

  return (
    <PageLayout title="Emergency Center" subtitle="Incident management and emergency coordination">
      {/* Alert Banner */}
      {alertActive && (
        <div className="mb-6 p-4 rounded-xl flex items-center gap-3 animate-pulse-glow" style={{ background: 'rgba(239,68,68,0.1)', border: '2px solid #ef4444' }}>
          <AlertTriangle size={20} style={{ color: '#ef4444', flexShrink: 0 }} />
          <p className="font-bold" style={{ color: '#ef4444' }}>EMERGENCY ALERT ACTIVE — All units responding to medical emergency in Section B</p>
          <button onClick={() => setAlertActive(false)} className="ml-auto text-xs px-3 py-1 rounded-lg font-semibold" style={{ background: 'rgba(239,68,68,0.2)', color: '#ef4444', border: '1px solid rgba(239,68,68,0.4)', cursor: 'pointer' }}>Dismiss</button>
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Active Incidents', value: '2', color: '#ef4444', icon: AlertTriangle },
          { label: 'Medical Teams', value: '8', color: '#00e5a0', icon: Activity },
          { label: 'Security Units', value: '12', color: '#0080ff', icon: Shield },
          { label: 'Response Time', value: '2.4 min', color: '#f59e0b', icon: Clock },
        ].map(({ label, value, color, icon: Icon }) => (
          <div key={label} className="stat-card flex items-center gap-3">
            <Icon size={20} style={{ color, flexShrink: 0 }} />
            <div>
              <div className="text-2xl font-black" style={{ color }}>{value}</div>
              <div className="text-xs" style={{ color: '#7a9cc0' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Incident Log */}
        <div className="card md:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>Active & Recent Incidents</h3>
            <button onClick={() => setAlertActive(true)} className="btn-secondary text-xs" style={{ padding: '0.25rem 0.75rem', borderColor: 'rgba(239,68,68,0.4)', color: '#ef4444' }}>
              + Report Emergency
            </button>
          </div>
          <div className="space-y-3">
            {INCIDENTS.map(({ id, type, desc, severity, time, status, responder }) => {
              const color = severity === 'critical' ? '#ef4444' : severity === 'high' ? '#f59e0b' : severity === 'medium' ? '#0080ff' : '#00e5a0'
              const statusColor = status === 'resolved' ? '#00e5a0' : status === 'responding' ? '#ef4444' : '#f59e0b'
              return (
                <div key={id} className="p-4 rounded-xl" style={{ background: `${color}06`, border: `1px solid ${color}20` }}>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xs font-mono font-bold" style={{ color }}>{id}</span>
                    <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: `${color}20`, color }}>{type}</span>
                    <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: `${statusColor}20`, color: statusColor }}>{status}</span>
                    <span className="text-xs ml-auto" style={{ color: '#7a9cc0' }}>{time}</span>
                  </div>
                  <p className="text-sm font-medium" style={{ color: '#e8f4ff' }}>{desc}</p>
                  <p className="text-xs mt-1" style={{ color: '#7a9cc0' }}>Responder: {responder}</p>
                </div>
              )
            })}
          </div>
        </div>

        {/* Emergency Contacts */}
        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Emergency Contacts</h3>
          <div className="space-y-3">
            {CONTACTS.map(({ name, number, available }) => (
              <div key={name} className="flex items-center gap-3 p-2.5 rounded-lg" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <span className={`w-2 h-2 rounded-full flex-shrink-0 ${available ? 'bg-green-400' : 'bg-red-500'}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold truncate" style={{ color: '#e8f4ff' }}>{name}</p>
                  <p className="text-xs" style={{ color: '#7a9cc0' }}>{number}</p>
                </div>
                <button className="p-1.5 rounded-lg" style={{ background: available ? 'rgba(0,229,160,0.1)' : 'rgba(255,255,255,0.05)', border: `1px solid ${available ? 'rgba(0,229,160,0.3)' : 'rgba(255,255,255,0.1)'}`, cursor: available ? 'pointer' : 'not-allowed' }}>
                  <Phone size={12} style={{ color: available ? '#00e5a0' : '#3a5070' }} />
                </button>
              </div>
            ))}
          </div>

          <div className="mt-6 p-3 rounded-xl" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)' }}>
            <p className="text-xs font-bold mb-1" style={{ color: '#ef4444' }}>GLOBAL EMERGENCY</p>
            <p className="text-xs" style={{ color: '#7a9cc0' }}>Press the button below to broadcast an all-hands emergency alert to all staff and units.</p>
            <button onClick={() => setAlertActive(true)} style={{ marginTop: '0.75rem', width: '100%', padding: '0.625rem', background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.5)', borderRadius: '8px', color: '#ef4444', fontWeight: 700, fontSize: '0.875rem', cursor: 'pointer' }}>
              🚨 BROADCAST ALERT
            </button>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
