export default function LoadingScreen() {
  return (
    <div className="fixed inset-0 flex items-center justify-center" style={{ background: '#050d1a', zIndex: 9999 }}>
      <div className="text-center">
        <div className="relative w-16 h-16 mx-auto mb-4">
          <div className="absolute inset-0 rounded-full border-2 border-transparent" style={{ borderTopColor: '#00e5a0', animation: 'spin 1s linear infinite' }} />
          <div className="absolute inset-2 rounded-full border-2 border-transparent" style={{ borderTopColor: 'rgba(0,229,160,0.4)', animation: 'spin 1.5s linear infinite reverse' }} />
          <div className="absolute inset-[6px] rounded-full flex items-center justify-center">
            <span style={{ color: '#00e5a0', fontSize: '20px' }}>⚽</span>
          </div>
        </div>
        <p style={{ color: '#00e5a0', fontSize: '0.875rem', letterSpacing: '0.1em', fontWeight: 600 }}>LOADING</p>
      </div>
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
