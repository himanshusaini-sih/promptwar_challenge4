import { useState } from 'react'
import { Shield, Users, Settings, Activity, Key } from 'lucide-react'
import PageLayout from '../components/PageLayout'

const USERS = [
  { name: 'Ahmed Al-Rashid', email: 'ahmed@fifa.com', role: 'Organizer', status: 'active', last: '2 min ago' },
  { name: 'Maria Santos', email: 'maria@fifa.com', role: 'Staff', status: 'active', last: '8 min ago' },
  { name: 'James Carter', email: 'james@fifa.com', role: 'Volunteer', status: 'active', last: '15 min ago' },
  { name: 'Liu Wei', email: 'liu@fifa.com', role: 'Staff', status: 'inactive', last: '2 hrs ago' },
  { name: 'Fatima Hassan', email: 'fatima@fifa.com', role: 'Organizer', status: 'active', last: '5 min ago' },
]

const SYSTEM_LOGS = [
  { event: 'User login: ahmed@fifa.com', time: '09:12:04', level: 'info' },
  { event: 'API rate limit exceeded on /api/crowd', time: '09:08:51', level: 'warning' },
  { event: 'Database backup completed successfully', time: '09:00:00', level: 'success' },
  { event: 'Failed authentication attempt from 192.168.1.45', time: '08:58:22', level: 'error' },
  { event: 'New event created: Brazil vs Argentina', time: '08:45:10', level: 'info' },
]

const roleColors: Record<string, string> = {
  Organizer: '#00e5a0',
  Staff: '#0080ff',
  Volunteer: '#f59e0b',
  Admin: '#8b5cf6',
  Fan: '#7a9cc0',
}

export default function AdminPanel() {
  const [activeSection, setActiveSection] = useState('users')

  const sections = [
    { id: 'users', label: 'Users', icon: Users },
    { id: 'system', label: 'System', icon: Activity },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'settings', label: 'Config', icon: Settings },
  ]

  return (
    <PageLayout title="Admin Panel" subtitle="System administration and user management">
      {/* Section Tabs */}
      <div className="flex gap-1 mb-8 p-1 rounded-xl w-fit" style={{ background: 'rgba(255,255,255,0.04)' }}>
        {sections.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setActiveSection(id)}
            style={{
              padding: '0.4rem 1rem', borderRadius: '8px', fontSize: '0.8125rem', fontWeight: 600,
              border: 'none', cursor: 'pointer',
              background: activeSection === id ? 'rgba(0,229,160,0.15)' : 'transparent',
              color: activeSection === id ? '#00e5a0' : '#7a9cc0',
              display: 'flex', alignItems: 'center', gap: '0.375rem',
            }}><Icon size={13} />{label}</button>
        ))}
      </div>

      {activeSection === 'users' && (
        <div className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Total Users', value: '1,248', color: '#00e5a0' },
              { label: 'Active Now', value: '342', color: '#0080ff' },
              { label: 'Organizers', value: '28', color: '#f59e0b' },
              { label: 'Volunteers', value: '456', color: '#8b5cf6' },
            ].map(({ label, value, color }) => (
              <div key={label} className="stat-card">
                <div className="text-xs font-semibold mb-1" style={{ color: '#7a9cc0' }}>{label.toUpperCase()}</div>
                <div className="text-2xl font-black" style={{ color }}>{value}</div>
              </div>
            ))}
          </div>

          {/* User Table */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>User Management</h3>
              <button className="btn-primary text-xs" style={{ padding: '0.35rem 0.875rem' }}>+ Add User</button>
            </div>
            <div className="overflow-x-auto">
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid rgba(0,229,160,0.12)' }}>
                    {['Name', 'Email', 'Role', 'Status', 'Last Active', 'Actions'].map(h => (
                      <th key={h} style={{ padding: '0.5rem 0.75rem', textAlign: 'left', fontSize: '0.75rem', fontWeight: 600, color: '#7a9cc0' }}>{h.toUpperCase()}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {USERS.map(({ name, email, role, status, last }) => (
                    <tr key={email} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                      <td style={{ padding: '0.75rem', color: '#e8f4ff', fontSize: '0.875rem', fontWeight: 500 }}>{name}</td>
                      <td style={{ padding: '0.75rem', color: '#7a9cc0', fontSize: '0.875rem' }}>{email}</td>
                      <td style={{ padding: '0.75rem' }}>
                        <span style={{ padding: '0.15rem 0.6rem', borderRadius: 999, fontSize: '0.75rem', fontWeight: 600, background: `${roleColors[role] || '#7a9cc0'}20`, color: roleColors[role] || '#7a9cc0' }}>{role}</span>
                      </td>
                      <td style={{ padding: '0.75rem' }}>
                        <span style={{ fontSize: '0.75rem', color: status === 'active' ? '#00e5a0' : '#7a9cc0' }}>{status === 'active' ? '● Active' : '○ Inactive'}</span>
                      </td>
                      <td style={{ padding: '0.75rem', color: '#7a9cc0', fontSize: '0.75rem' }}>{last}</td>
                      <td style={{ padding: '0.75rem' }}>
                        <div className="flex gap-2">
                          <button style={{ padding: '0.25rem 0.625rem', background: 'transparent', border: '1px solid rgba(0,229,160,0.2)', borderRadius: '6px', color: '#00e5a0', fontSize: '0.75rem', cursor: 'pointer' }}>Edit</button>
                          <button style={{ padding: '0.25rem 0.625rem', background: 'transparent', border: '1px solid rgba(239,68,68,0.2)', borderRadius: '6px', color: '#ef4444', fontSize: '0.75rem', cursor: 'pointer' }}>Suspend</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'system' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: 'API Status', value: '99.9% uptime', color: '#00e5a0', detail: '12ms avg response' },
              { label: 'Database', value: 'Healthy', color: '#00e5a0', detail: '2.1GB used / 50GB' },
              { label: 'WebSocket', value: '342 connections', color: '#0080ff', detail: 'Real-time active' },
            ].map(({ label, value, color, detail }) => (
              <div key={label} className="stat-card">
                <div className="text-xs font-semibold mb-1" style={{ color: '#7a9cc0' }}>{label.toUpperCase()}</div>
                <div className="text-xl font-black" style={{ color }}>{value}</div>
                <div className="text-xs mt-1" style={{ color: '#7a9cc0' }}>{detail}</div>
              </div>
            ))}
          </div>

          <div className="card">
            <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>System Logs</h3>
            <div className="space-y-2 font-mono text-xs">
              {SYSTEM_LOGS.map(({ event, time, level }) => {
                const color = level === 'error' ? '#ef4444' : level === 'warning' ? '#f59e0b' : level === 'success' ? '#00e5a0' : '#7a9cc0'
                return (
                  <div key={event} className="flex gap-3 p-2 rounded" style={{ background: 'rgba(255,255,255,0.02)' }}>
                    <span style={{ color: '#3a5070', flexShrink: 0 }}>{time}</span>
                    <span style={{ color: `${color}`, fontWeight: 600, flexShrink: 0, width: 60 }}>[{level.toUpperCase()}]</span>
                    <span style={{ color: '#e8f4ff' }}>{event}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {(activeSection === 'security' || activeSection === 'settings') && (
        <div className="card">
          <div className="flex items-center gap-3 mb-4">
            {activeSection === 'security' ? <Key size={20} style={{ color: '#00e5a0' }} /> : <Settings size={20} style={{ color: '#00e5a0' }} />}
            <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>{activeSection === 'security' ? 'Security Settings' : 'System Configuration'}</h3>
          </div>
          <div className="space-y-4">
            {(activeSection === 'security' ? [
              ['Two-Factor Authentication', true] as [string, boolean],
              ['IP Whitelisting', false] as [string, boolean],
              ['Session Timeout (30 min)', true] as [string, boolean],
              ['Audit Logging', true] as [string, boolean],
              ['Failed Login Lockout', true] as [string, boolean],
            ] : [
              ['Maintenance Mode', false] as [string, boolean],
              ['Real-Time Notifications', true] as [string, boolean],
              ['AI Features Enabled', true] as [string, boolean],
              ['Public API Access', false] as [string, boolean],
              ['Auto-Scale on Peak Load', true] as [string, boolean],
            ]).map(([label, enabled]) => (
              <div key={label} className="flex items-center justify-between p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <span className="text-sm font-medium" style={{ color: '#e8f4ff' }}>{label as string}</span>
                <button style={{
                  width: '44px', height: '24px', borderRadius: '12px', border: 'none', cursor: 'pointer',
                  background: (enabled as boolean) ? '#00e5a0' : 'rgba(255,255,255,0.1)',
                  position: 'relative', transition: 'background 0.2s',
                }}>
                  <span style={{
                    position: 'absolute', top: '3px', left: (enabled as boolean) ? '23px' : '3px',
                    width: '18px', height: '18px', borderRadius: '50%',
                    background: (enabled as boolean) ? '#050d1a' : '#7a9cc0',
                    transition: 'left 0.2s',
                  }} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </PageLayout>
  )
}
