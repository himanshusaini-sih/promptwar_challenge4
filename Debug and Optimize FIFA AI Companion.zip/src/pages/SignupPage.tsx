import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'

export default function SignupPage() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'fan' })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    await new Promise(r => setTimeout(r, 800))
    setLoading(false)
    navigate('/fan')
  }

  const update = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const inputStyle = {
    width: '100%',
    padding: '0.625rem 0.875rem',
    background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(0,229,160,0.2)',
    borderRadius: '8px',
    color: '#e8f4ff',
    fontSize: '0.875rem',
    outline: 'none',
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 grid-bg" style={{ background: '#050d1a' }}>
      <div className="w-full max-w-md animate-fade-in">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00e5a0, #0080ff)' }}>
              <span className="text-lg">⚽</span>
            </div>
            <span className="font-bold text-lg" style={{ color: '#00e5a0' }}>FIFA AI Stadium</span>
          </Link>
          <h1 className="text-2xl font-bold mt-4" style={{ color: '#e8f4ff' }}>Create an account</h1>
          <p className="text-sm mt-1" style={{ color: '#7a9cc0' }}>Join the future of stadium experiences</p>
        </div>

        <div className="card p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>FULL NAME</label>
              <input style={inputStyle} value={form.name} onChange={e => update('name', e.target.value)} placeholder="John Smith" required
                onFocus={e => (e.target.style.borderColor = '#00e5a0')}
                onBlur={e => (e.target.style.borderColor = 'rgba(0,229,160,0.2)')} />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>EMAIL</label>
              <input type="email" style={inputStyle} value={form.email} onChange={e => update('email', e.target.value)} placeholder="you@example.com" required
                onFocus={e => (e.target.style.borderColor = '#00e5a0')}
                onBlur={e => (e.target.style.borderColor = 'rgba(0,229,160,0.2)')} />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>PASSWORD</label>
              <input type="password" style={inputStyle} value={form.password} onChange={e => update('password', e.target.value)} placeholder="••••••••" required
                onFocus={e => (e.target.style.borderColor = '#00e5a0')}
                onBlur={e => (e.target.style.borderColor = 'rgba(0,229,160,0.2)')} />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>ROLE</label>
              <select
                value={form.role}
                onChange={e => update('role', e.target.value)}
                style={{ ...inputStyle, cursor: 'pointer' }}
              >
                {['fan', 'organizer', 'volunteer', 'staff'].map(r => (
                  <option key={r} value={r} style={{ background: '#0a1932' }}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>
                ))}
              </select>
            </div>

            <button type="submit" disabled={loading} className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '0.75rem', fontSize: '0.9375rem', opacity: loading ? 0.7 : 1 }}>
              {loading ? 'Creating account...' : <><span>Create Account</span><ArrowRight size={16} /></>}
            </button>
          </form>

          <p className="text-center text-sm mt-6" style={{ color: '#7a9cc0' }}>
            Already have an account?{' '}
            <Link to="/login" style={{ color: '#00e5a0', fontWeight: 600 }}>Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
