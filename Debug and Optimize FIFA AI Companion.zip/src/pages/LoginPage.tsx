import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { Eye, EyeOff, ArrowRight } from 'lucide-react'

const ROLES = [
  { value: 'fan', label: 'Fan', path: '/fan' },
  { value: 'organizer', label: 'Organizer', path: '/organizer' },
  { value: 'volunteer', label: 'Volunteer', path: '/volunteer' },
  { value: 'staff', label: 'Staff', path: '/staff' },
  { value: 'admin', label: 'Admin', path: '/admin' },
]

export default function LoginPage() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('fan')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password) { setError('Please fill in all fields'); return }
    setLoading(true)
    setError('')
    await new Promise(r => setTimeout(r, 800))
    setLoading(false)
    const target = ROLES.find(r => r.value === role)?.path || '/fan'
    navigate(target)
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 grid-bg" style={{ background: '#050d1a' }}>
      <div className="absolute top-20 left-1/3 w-80 h-80 rounded-full opacity-10 pointer-events-none" style={{ background: 'radial-gradient(circle, #00e5a0, transparent)', filter: 'blur(60px)' }} />

      <div className="w-full max-w-md animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00e5a0, #0080ff)' }}>
              <span className="text-lg">⚽</span>
            </div>
            <span className="font-bold text-lg" style={{ color: '#00e5a0' }}>FIFA AI Stadium</span>
          </Link>
          <h1 className="text-2xl font-bold mt-2" style={{ color: '#e8f4ff' }}>Welcome back</h1>
          <p className="text-sm mt-1" style={{ color: '#7a9cc0' }}>Sign in to your account</p>
        </div>

        <div className="card p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Role Selector */}
            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>ROLE</label>
              <div className="flex gap-2 flex-wrap">
                {ROLES.map(r => (
                  <button
                    type="button"
                    key={r.value}
                    onClick={() => setRole(r.value)}
                    style={{
                      padding: '0.375rem 0.75rem',
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      border: `1px solid ${role === r.value ? '#00e5a0' : 'rgba(0,229,160,0.2)'}`,
                      background: role === r.value ? 'rgba(0,229,160,0.15)' : 'transparent',
                      color: role === r.value ? '#00e5a0' : '#7a9cc0',
                      cursor: 'pointer',
                    }}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>EMAIL</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                style={{
                  width: '100%',
                  padding: '0.625rem 0.875rem',
                  background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(0,229,160,0.2)',
                  borderRadius: '8px',
                  color: '#e8f4ff',
                  fontSize: '0.875rem',
                  outline: 'none',
                }}
                onFocus={e => (e.target.style.borderColor = '#00e5a0')}
                onBlur={e => (e.target.style.borderColor = 'rgba(0,229,160,0.2)')}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>PASSWORD</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  style={{
                    width: '100%',
                    padding: '0.625rem 2.5rem 0.625rem 0.875rem',
                    background: 'rgba(255,255,255,0.04)',
                    border: '1px solid rgba(0,229,160,0.2)',
                    borderRadius: '8px',
                    color: '#e8f4ff',
                    fontSize: '0.875rem',
                    outline: 'none',
                  }}
                  onFocus={e => (e.target.style.borderColor = '#00e5a0')}
                  onBlur={e => (e.target.style.borderColor = 'rgba(0,229,160,0.2)')}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{ position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: '#7a9cc0', background: 'none', border: 'none', cursor: 'pointer' }}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && <p className="text-xs" style={{ color: '#ef4444' }}>{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full justify-center"
              style={{ width: '100%', padding: '0.75rem', fontSize: '0.9375rem', opacity: loading ? 0.7 : 1 }}
            >
              {loading ? 'Signing in...' : <><span>Sign In</span><ArrowRight size={16} /></>}
            </button>
          </form>

          <p className="text-center text-sm mt-6" style={{ color: '#7a9cc0' }}>
            Don't have an account?{' '}
            <Link to="/signup" style={{ color: '#00e5a0', fontWeight: 600 }}>Sign up</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
