import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'
import { Ticket, MapPin, MessageSquare, Bell, Clock, ChevronRight, Wifi, Coffee, ShieldCheck } from 'lucide-react'
import PageLayout from '../components/PageLayout'

const attendanceData = [
  { time: '10:00', count: 12000 },
  { time: '11:00', count: 28000 },
  { time: '12:00', count: 45000 },
  { time: '13:00', count: 62000 },
  { time: '14:00', count: 78000 },
  { time: '15:00', count: 89000 },
  { time: '16:00', count: 94000 },
]

const queueData = [
  { gate: 'Gate A', wait: 8 },
  { gate: 'Gate B', wait: 3 },
  { gate: 'Gate C', wait: 12 },
  { gate: 'Gate D', wait: 5 },
  { gate: 'Gate E', wait: 7 },
]

const MATCHES = [
  { teams: 'Brazil vs Argentina', time: 'Today, 20:00', venue: 'Lusail Stadium', status: 'upcoming', seat: 'Block C, Row 12, Seat 7' },
  { teams: 'France vs Germany', time: 'Jul 14, 17:00', venue: 'Al Bayt Stadium', status: 'ticketed', seat: 'Block A, Row 5, Seat 22' },
  { teams: 'Spain vs Portugal', time: 'Jul 18, 20:00', venue: "King Fahd Stadium", status: 'available', seat: null },
]

const ALERTS = [
  { msg: 'Gate B is now open — shortest queue', time: '2 min ago', type: 'info' },
  { msg: 'Your match starts in 45 minutes', time: '5 min ago', type: 'warning' },
  { msg: 'Seat upgrade available — Row 3', time: '12 min ago', type: 'success' },
]

const SERVICES = [
  { icon: Coffee, label: 'Food & Beverage', desc: 'Order to your seat' },
  { icon: Wifi, label: 'Stadium WiFi', desc: 'Connected: FIFA_STADIUM_5G' },
  { icon: MapPin, label: 'Navigate Stadium', desc: 'Get directions' },
  { icon: ShieldCheck, label: 'Lost & Found', desc: 'Report or retrieve items' },
]

export default function FanDashboard() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('overview')

  return (
    <PageLayout title="Fan Hub" subtitle="Your personal match-day companion">
      {/* Tabs */}
      <div className="flex gap-1 mb-8 p-1 rounded-xl w-fit" style={{ background: 'rgba(255,255,255,0.04)' }}>
        {['overview', 'my tickets', 'services'].map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            style={{
              padding: '0.5rem 1.25rem',
              borderRadius: '8px',
              fontSize: '0.8125rem',
              fontWeight: 600,
              border: 'none',
              cursor: 'pointer',
              textTransform: 'capitalize',
              background: activeTab === tab ? 'rgba(0,229,160,0.15)' : 'transparent',
              color: activeTab === tab ? '#00e5a0' : '#7a9cc0',
              transition: 'all 0.15s',
            }}
          >{tab}</button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Stat Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Attendance', value: '89,241', sub: '94.9% capacity', color: '#00e5a0' },
              { label: 'My Gate', value: 'Gate B', sub: '~3 min wait', color: '#0080ff' },
              { label: 'Next Match', value: '2h 15m', sub: 'BRA vs ARG', color: '#f59e0b' },
              { label: 'Fan Score', value: '★ 4.8', sub: 'Top supporter', color: '#8b5cf6' },
            ].map(({ label, value, sub, color }) => (
              <div key={label} className="stat-card">
                <div className="text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>{label.toUpperCase()}</div>
                <div className="text-2xl font-black" style={{ color }}>{value}</div>
                <div className="text-xs mt-1" style={{ color: '#7a9cc0' }}>{sub}</div>
              </div>
            ))}
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="card md:col-span-2">
              <h3 className="font-bold mb-4 text-sm" style={{ color: '#e8f4ff' }}>Stadium Attendance Today</h3>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={attendanceData}>
                  <defs>
                    <linearGradient id="aGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00e5a0" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#00e5a0" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#7a9cc0' }} axisLine={false} tickLine={false} width={50} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
                  <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 12 }} />
                  <Area type="monotone" dataKey="count" stroke="#00e5a0" strokeWidth={2} fill="url(#aGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="card">
              <h3 className="font-bold mb-4 text-sm" style={{ color: '#e8f4ff' }}>Gate Wait Times (min)</h3>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={queueData}>
                  <XAxis dataKey="gate" tick={{ fontSize: 11, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 12 }} />
                  <Bar dataKey="wait" fill="#0080ff" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Alerts */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>Live Alerts</h3>
              <Bell size={16} style={{ color: '#7a9cc0' }} />
            </div>
            <div className="space-y-3">
              {ALERTS.map(({ msg, time, type }) => {
                const color = type === 'success' ? '#00e5a0' : type === 'warning' ? '#f59e0b' : '#0080ff'
                return (
                  <div key={msg} className="flex items-start gap-3 p-3 rounded-lg" style={{ background: 'rgba(255,255,255,0.03)' }}>
                    <span className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ background: color }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm" style={{ color: '#e8f4ff' }}>{msg}</p>
                      <p className="text-xs mt-0.5" style={{ color: '#7a9cc0' }}>{time}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'my tickets' && (
        <div className="space-y-4">
          {MATCHES.map(({ teams, time, venue, status, seat }) => (
            <div key={teams} className="card flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(0,229,160,0.1)', border: '1px solid rgba(0,229,160,0.25)' }}>
                <Ticket size={20} style={{ color: '#00e5a0' }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold" style={{ color: '#e8f4ff' }}>{teams}</p>
                <p className="text-xs mt-0.5" style={{ color: '#7a9cc0' }}><Clock size={11} className="inline mr-1" />{time} · {venue}</p>
                {seat && <p className="text-xs mt-1" style={{ color: '#00e5a0' }}><MapPin size={11} className="inline mr-1" />{seat}</p>}
              </div>
              <span style={{
                padding: '0.25rem 0.75rem',
                borderRadius: '999px',
                fontSize: '0.75rem',
                fontWeight: 600,
                background: status === 'upcoming' ? 'rgba(0,229,160,0.15)' : status === 'ticketed' ? 'rgba(0,128,255,0.15)' : 'rgba(245,158,11,0.15)',
                color: status === 'upcoming' ? '#00e5a0' : status === 'ticketed' ? '#0080ff' : '#f59e0b',
              }}>{status}</span>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'services' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {SERVICES.map(({ icon: Icon, label, desc }) => (
            <button key={label} className="card text-left flex items-center gap-4" style={{ cursor: 'pointer' }}>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(0,128,255,0.1)', border: '1px solid rgba(0,128,255,0.25)' }}>
                <Icon size={20} style={{ color: '#0080ff' }} />
              </div>
              <div className="flex-1">
                <p className="font-bold text-sm" style={{ color: '#e8f4ff' }}>{label}</p>
                <p className="text-xs mt-0.5" style={{ color: '#7a9cc0' }}>{desc}</p>
              </div>
              <ChevronRight size={16} style={{ color: '#7a9cc0' }} />
            </button>
          ))}
          <button onClick={() => navigate('/chatbot')} className="card text-left flex items-center gap-4 md:col-span-2" style={{ cursor: 'pointer', borderColor: 'rgba(0,229,160,0.3)' }}>
            <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(0,229,160,0.1)', border: '1px solid rgba(0,229,160,0.3)' }}>
              <MessageSquare size={20} style={{ color: '#00e5a0' }} />
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm" style={{ color: '#00e5a0' }}>AI Stadium Assistant</p>
              <p className="text-xs mt-0.5" style={{ color: '#7a9cc0' }}>Ask anything about the stadium, schedule, or services</p>
            </div>
            <ChevronRight size={16} style={{ color: '#00e5a0' }} />
          </button>
        </div>
      )}
    </PageLayout>
  )
}
