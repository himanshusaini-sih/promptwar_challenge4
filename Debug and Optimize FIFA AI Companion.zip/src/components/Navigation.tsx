import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Users, MessageSquare, BarChart3, Shield,
  Truck, AlertTriangle, Settings, Menu, X, LogOut, UserCircle
} from 'lucide-react'

const NAV_ITEMS = [
  { path: '/fan', label: 'Fan Hub', icon: LayoutDashboard },
  { path: '/organizer', label: 'Organizer', icon: Users },
  { path: '/volunteer', label: 'Volunteer', icon: UserCircle },
  { path: '/staff', label: 'Staff', icon: Shield },
  { path: '/chatbot', label: 'AI Assistant', icon: MessageSquare },
  { path: '/analytics', label: 'Analytics', icon: BarChart3 },
  { path: '/crowd', label: 'Crowd', icon: Users },
  { path: '/transportation', label: 'Transport', icon: Truck },
  { path: '/emergency', label: 'Emergency', icon: AlertTriangle },
  { path: '/admin', label: 'Admin', icon: Shield },
  { path: '/settings', label: 'Settings', icon: Settings },
]

const HIDDEN_PATHS = ['/', '/login', '/signup']

export default function Navigation() {
  const location = useLocation()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  if (HIDDEN_PATHS.includes(location.pathname)) return null

  return (
    <aside
      className="fixed left-0 top-0 h-full z-40 flex flex-col transition-all duration-300"
      style={{
        width: sidebarOpen ? '220px' : '64px',
        background: 'rgba(5, 13, 26, 0.95)',
        backdropFilter: 'blur(20px)',
        borderRight: '1px solid rgba(0, 229, 160, 0.12)',
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b" style={{ borderColor: 'rgba(0,229,160,0.12)' }}>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{ background: 'linear-gradient(135deg, #00e5a0, #0080ff)' }}>
          <span className="text-sm font-bold">⚽</span>
        </div>
        {sidebarOpen && (
          <div>
            <div className="text-xs font-bold" style={{ color: '#00e5a0', letterSpacing: '0.08em' }}>FIFA AI</div>
            <div className="text-xs" style={{ color: '#7a9cc0' }}>Stadium</div>
          </div>
        )}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="ml-auto p-1 rounded-md"
          style={{ color: '#7a9cc0', background: 'none', border: 'none', cursor: 'pointer' }}
        >
          {sidebarOpen ? <X size={14} /> : <Menu size={14} />}
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map(({ path, label, icon: Icon }) => {
          const active = location.pathname === path
          return (
            <Link
              key={path}
              to={path}
              title={!sidebarOpen ? label : undefined}
              style={{
                color: active ? '#00e5a0' : '#7a9cc0',
                background: active ? 'rgba(0, 229, 160, 0.1)' : 'transparent',
                borderRadius: '8px',
                padding: '0.5rem',
                display: 'flex',
                alignItems: 'center',
                gap: sidebarOpen ? '0.625rem' : '0',
                justifyContent: sidebarOpen ? 'flex-start' : 'center',
                fontWeight: active ? 600 : 500,
                fontSize: '0.8125rem',
                textDecoration: 'none',
                transition: 'all 0.15s',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
              }}
            >
              <Icon size={16} style={{ flexShrink: 0 }} />
              {sidebarOpen && <span>{label}</span>}
            </Link>
          )
        })}
      </nav>

      {/* Logout */}
      <div className="p-2 border-t" style={{ borderColor: 'rgba(0,229,160,0.12)' }}>
        <button
          onClick={() => navigate('/login')}
          title={!sidebarOpen ? 'Logout' : undefined}
          style={{
            width: '100%', color: '#7a9cc0', background: 'transparent', border: 'none',
            borderRadius: '8px', padding: '0.5rem', display: 'flex', alignItems: 'center',
            gap: sidebarOpen ? '0.625rem' : '0', justifyContent: sidebarOpen ? 'flex-start' : 'center',
            fontSize: '0.8125rem', cursor: 'pointer', transition: 'color 0.15s',
          }}
          onMouseEnter={e => (e.currentTarget.style.color = '#ef4444')}
          onMouseLeave={e => (e.currentTarget.style.color = '#7a9cc0')}
        >
          <LogOut size={16} style={{ flexShrink: 0 }} />
          {sidebarOpen && <span>Logout</span>}
        </button>
      </div>
    </aside>
  )
}
