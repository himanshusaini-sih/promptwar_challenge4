import { Suspense, lazy } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Navigation from './components/Navigation'
import LoadingScreen from './components/LoadingScreen'

const LandingPage = lazy(() => import('./pages/LandingPage'))
const LoginPage = lazy(() => import('./pages/LoginPage'))
const SignupPage = lazy(() => import('./pages/SignupPage'))
const FanDashboard = lazy(() => import('./pages/FanDashboard'))
const OrganizerDashboard = lazy(() => import('./pages/OrganizerDashboard'))
const VolunteerDashboard = lazy(() => import('./pages/VolunteerDashboard'))
const StaffDashboard = lazy(() => import('./pages/StaffDashboard'))
const AdminPanel = lazy(() => import('./pages/AdminPanel'))
const ChatbotPage = lazy(() => import('./pages/ChatbotPage'))
const AnalyticsPage = lazy(() => import('./pages/AnalyticsPage'))
const CrowdManagement = lazy(() => import('./pages/CrowdManagement'))
const TransportationPage = lazy(() => import('./pages/TransportationPage'))
const EmergencyCenter = lazy(() => import('./pages/EmergencyCenter'))
const SettingsPage = lazy(() => import('./pages/SettingsPage'))
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'))

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen" style={{ background: '#050d1a' }}>
        <Navigation />
        <Suspense fallback={<LoadingScreen />}>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/dashboard" element={<Navigate to="/fan" replace />} />
            <Route path="/fan" element={<FanDashboard />} />
            <Route path="/organizer" element={<OrganizerDashboard />} />
            <Route path="/volunteer" element={<VolunteerDashboard />} />
            <Route path="/staff" element={<StaffDashboard />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/chatbot" element={<ChatbotPage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/crowd" element={<CrowdManagement />} />
            <Route path="/transportation" element={<TransportationPage />} />
            <Route path="/emergency" element={<EmergencyCenter />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Suspense>
      </div>
    </BrowserRouter>
  )
}
