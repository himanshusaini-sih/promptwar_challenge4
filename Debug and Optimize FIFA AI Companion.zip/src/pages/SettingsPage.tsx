import { useState } from 'react'
import { User, Bell, Shield, LogOut } from 'lucide-react'
import PageLayout from '../components/PageLayout'
import { useNavigate } from 'react-router-dom'

export default function SettingsPage() {
  const navigate = useNavigate()
  const [notifications, setNotifications] = useState({ matches: true, crowd: true, transport: false, emergency: true, news: false })
  const [profile, setProfile] = useState({ name: 'John Smith', email: 'john@example.com', role: 'Fan' })

  const toggle = (key: keyof typeof notifications) => setNotifications(n => ({ ...n, [key]: !n[key] }))

  return (
    <PageLayout title="Settings" subtitle="Account preferences and notifications">
      <div className="max-w-2xl space-y-6">
        {/* Profile */}
        <div className="card">
          <div className="flex items-center gap-3 mb-5">
            <User size={18} style={{ color: '#00e5a0' }} />
            <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>Profile</h3>
          </div>
          <div className="space-y-4">
            {[
              { label: 'Full Name', key: 'name', value: profile.name },
              { label: 'Email', key: 'email', value: profile.email },
            ].map(({ label, key, value }) => (
              <div key={key}>
                <label className="block text-xs font-semibold mb-1.5" style={{ color: '#7a9cc0', letterSpacing: '0.05em' }}>{label.toUpperCase()}</label>
                <input
                  value={value}
                  onChange={e => setProfile(p => ({ ...p, [key]: e.target.value }))}
                  style={{ width: '100%', padding: '0.625rem 0.875rem', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(0,229,160,0.2)', borderRadius: '8px', color: '#e8f4ff', fontSize: '0.875rem', outline: 'none' }}
                  onFocus={e => (e.target.style.borderColor = '#00e5a0')}
                  onBlur={e => (e.target.style.borderColor = 'rgba(0,229,160,0.2)')}
                />
              </div>
            ))}
            <button className="btn-primary text-sm" style={{ padding: '0.5rem 1.25rem' }}>Save Changes</button>
          </div>
        </div>

        {/* Notifications */}
        <div className="card">
          <div className="flex items-center gap-3 mb-5">
            <Bell size={18} style={{ color: '#00e5a0' }} />
            <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>Notifications</h3>
          </div>
          <div className="space-y-3">
            {[
              { key: 'matches', label: 'Match updates & reminders', desc: 'Get notified when your match is about to start' },
              { key: 'crowd', label: 'Crowd & queue alerts', desc: 'Know when queues are short near your gate' },
              { key: 'transport', label: 'Transport updates', desc: 'Bus and metro delay notifications' },
              { key: 'emergency', label: 'Emergency alerts', desc: 'Critical safety notifications (recommended)' },
              { key: 'news', label: 'News & promotions', desc: 'Stadium offers and event news' },
            ].map(({ key, label, desc }) => (
              <div key={key} className="flex items-center justify-between p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <div>
                  <p className="text-sm font-medium" style={{ color: '#e8f4ff' }}>{label}</p>
                  <p className="text-xs mt-0.5" style={{ color: '#7a9cc0' }}>{desc}</p>
                </div>
                <button
                  onClick={() => toggle(key as keyof typeof notifications)}
                  style={{
                    width: '44px', height: '24px', borderRadius: '12px', border: 'none', cursor: 'pointer',
                    background: notifications[key as keyof typeof notifications] ? '#00e5a0' : 'rgba(255,255,255,0.1)',
                    position: 'relative', transition: 'background 0.2s', flexShrink: 0,
                  }}
                >
                  <span style={{
                    position: 'absolute', top: '3px',
                    left: notifications[key as keyof typeof notifications] ? '23px' : '3px',
                    width: '18px', height: '18px', borderRadius: '50%',
                    background: notifications[key as keyof typeof notifications] ? '#050d1a' : '#7a9cc0',
                    transition: 'left 0.2s',
                  }} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Account Actions */}
        <div className="card">
          <div className="flex items-center gap-3 mb-5">
            <Shield size={18} style={{ color: '#00e5a0' }} />
            <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>Account</h3>
          </div>
          <div className="space-y-3">
            <button className="btn-secondary w-full justify-center" style={{ padding: '0.625rem' }}>Change Password</button>
            <button onClick={() => navigate('/login')} className="w-full flex items-center justify-center gap-2 p-2.5 rounded-lg font-semibold text-sm transition-colors" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: '#ef4444', cursor: 'pointer' }}>
              <LogOut size={15} /> Sign Out
            </button>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
