import { useState } from 'react'
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, Tooltip } from 'recharts'
import { Shield, AlertTriangle, Eye, Radio, Users } from 'lucide-react'
import PageLayout from '../components/PageLayout'

const securityData = [
  { zone: 'Gate A', score: 95 },
  { zone: 'Gate B', score: 88 },
  { zone: 'VIP Area', score: 99 },
  { zone: 'Field Side', score: 72 },
  { zone: 'South Stand', score: 85 },
  { zone: 'Car Park', score: 91 },
]

const ZONES = [
  { zone: 'Gate A – Main Entry', staff: 24, crowd: 'normal', cameras: 12, status: 'clear' },
  { zone: 'Gate B – North', staff: 18, crowd: 'high', cameras: 8, status: 'alert' },
  { zone: 'VIP Zone', staff: 36, crowd: 'normal', cameras: 20, status: 'clear' },
  { zone: 'Field Perimeter', staff: 48, crowd: 'restricted', cameras: 32, status: 'clear' },
  { zone: 'South Stand', staff: 22, crowd: 'high', cameras: 14, status: 'monitoring' },
]

const INCIDENTS = [
  { id: '#SEC-014', desc: 'Unauthorized attempt at VIP entrance', severity: 'high', time: '3m ago', responder: 'Unit Alpha' },
  { id: '#SEC-013', desc: 'Crowd density exceeding limit in Section B', severity: 'medium', time: '11m ago', responder: 'Unit Bravo' },
  { id: '#SEC-012', desc: 'Suspicious package reported — North concourse', severity: 'high', time: '28m ago', responder: 'EOD Team' },
]

export default function StaffDashboard() {
  const [selectedZone, setSelectedZone] = useState(0)

  return (
    <PageLayout title="Staff Operations" subtitle="Security monitoring and incident management">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Security Personnel', value: '1,248', icon: Shield, color: '#00e5a0' },
          { label: 'Active Cameras', value: '342', icon: Eye, color: '#0080ff' },
          { label: 'Open Incidents', value: '3', icon: AlertTriangle, color: '#ef4444' },
          { label: 'Radio Channels', value: '12', icon: Radio, color: '#f59e0b' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="stat-card flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${color}15`, border: `1px solid ${color}30` }}>
              <Icon size={18} style={{ color }} />
            </div>
            <div>
              <div className="text-2xl font-black" style={{ color }}>{value}</div>
              <div className="text-xs" style={{ color: '#7a9cc0' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Zone Table */}
        <div className="card md:col-span-2">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Zone Security Status</h3>
          <div className="space-y-2">
            {ZONES.map(({ zone, staff, crowd, cameras, status }, i) => {
              const statusColor = status === 'clear' ? '#00e5a0' : status === 'alert' ? '#ef4444' : '#f59e0b'
              return (
                <div key={zone} onClick={() => setSelectedZone(i)} className="p-3 rounded-xl cursor-pointer transition-all" style={{ background: selectedZone === i ? 'rgba(0,229,160,0.07)' : 'rgba(255,255,255,0.03)', border: `1px solid ${selectedZone === i ? 'rgba(0,229,160,0.25)' : 'transparent'}` }}>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm" style={{ color: '#e8f4ff' }}>{zone}</span>
                    <span style={{ padding: '0.15rem 0.6rem', borderRadius: 999, fontSize: '0.7rem', fontWeight: 700, background: `${statusColor}20`, color: statusColor }}>{status.toUpperCase()}</span>
                  </div>
                  <div className="flex gap-6 mt-1.5">
                    <span className="text-xs" style={{ color: '#7a9cc0' }}><Users size={11} className="inline mr-1" />{staff} staff</span>
                    <span className="text-xs" style={{ color: '#7a9cc0' }}><Eye size={11} className="inline mr-1" />{cameras} cameras</span>
                    <span className="text-xs" style={{ color: crowd === 'high' ? '#f59e0b' : crowd === 'restricted' ? '#8b5cf6' : '#7a9cc0' }}>crowd: {crowd}</span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Radar Chart */}
        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Zone Security Score</h3>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={securityData}>
              <PolarGrid stroke="rgba(255,255,255,0.08)" />
              <PolarAngleAxis dataKey="zone" tick={{ fontSize: 10, fill: '#7a9cc0' }} />
              <Radar name="Score" dataKey="score" stroke="#00e5a0" fill="#00e5a0" fillOpacity={0.2} />
              <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 12 }} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Incidents */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>Active Security Incidents</h3>
          <button className="btn-secondary text-xs" style={{ padding: '0.25rem 0.75rem' }}>+ Report Incident</button>
        </div>
        <div className="space-y-3">
          {INCIDENTS.map(({ id, desc, severity, time, responder }) => {
            const color = severity === 'high' ? '#ef4444' : '#f59e0b'
            return (
              <div key={id} className="p-4 rounded-xl" style={{ background: `${color}08`, border: `1px solid ${color}25` }}>
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle size={14} style={{ color }} />
                  <span className="text-xs font-mono font-bold" style={{ color }}>{id}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: `${color}20`, color }}>{severity}</span>
                  <span className="text-xs ml-auto" style={{ color: '#7a9cc0' }}>{time}</span>
                </div>
                <p className="text-sm" style={{ color: '#e8f4ff' }}>{desc}</p>
                <p className="text-xs mt-1" style={{ color: '#7a9cc0' }}>Responding: {responder}</p>
              </div>
            )
          })}
        </div>
      </div>
    </PageLayout>
  )
}
