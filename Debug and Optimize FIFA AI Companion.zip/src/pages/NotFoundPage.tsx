import { useNavigate } from 'react-router-dom'
import { Home, ArrowLeft } from 'lucide-react'

export default function NotFoundPage() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#050d1a' }}>
      <div className="text-center animate-fade-in">
        <div className="text-8xl font-black mb-4 gradient-text">404</div>
        <h1 className="text-2xl font-bold mb-2" style={{ color: '#e8f4ff' }}>Page Not Found</h1>
        <p className="mb-8" style={{ color: '#7a9cc0' }}>The page you're looking for doesn't exist or has been moved.</p>
        <div className="flex gap-4 justify-center">
          <button onClick={() => navigate(-1)} className="btn-secondary">
            <ArrowLeft size={16} /> Go Back
          </button>
          <button onClick={() => navigate('/')} className="btn-primary">
            <Home size={16} /> Home
          </button>
        </div>
      </div>
    </div>
  )
}
