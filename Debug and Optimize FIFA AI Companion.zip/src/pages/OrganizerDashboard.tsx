import { useState } from 'react'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid } from 'recharts'
import { Users, Calendar, AlertCircle, TrendingUp, Clock } from 'lucide-react'
import PageLayout from '../components/PageLayout'

const capacityData = [
  { name: 'Occupied', value: 89241, color: '#00e5a0' },
  { name: 'Available', value: 4759, color: 'rgba(0,229,160,0.15)' },
]

const revenueData = [
  { day: 'Mon', revenue: 240000, tickets: 18000 },
  { day: 'Tue', revenue: 380000, tickets: 29000 },
  { day: 'Wed', revenue: 520000, tickets: 41000 },
  { day: 'Thu', revenue: 890000, tickets: 67000 },
  { day: 'Fri', revenue: 1200000, tickets: 89000 },
  { day: 'Sat', revenue: 1450000, tickets: 94000 },
]

const EVENTS = [
  { name: 'Brazil vs Argentina', date: 'Jul 9, 20:00', status: 'live', tickets: 94000, capacity: 94000 },
  { name: 'France vs Germany', date: 'Jul 14, 17:00', status: 'scheduled', tickets: 78430, capacity: 94000 },
  { name: 'Spain vs Portugal', date: 'Jul 18, 20:00', status: 'scheduled', tickets: 45000, capacity: 94000 },
  { name: 'Quarter Final A', date: 'Jul 25, 20:00', status: 'draft', tickets: 12000, capacity: 94000 },
]

const INCIDENTS = [
  { id: '#INC-012', desc: 'Overcrowding at Gate C — dispatching stewards', severity: 'high', time: '5m ago' },
  { id: '#INC-011', desc: 'Food vendor complaint — Section 14', severity: 'low', time: '18m ago' },
  { id: '#INC-010', desc: 'Medical assistance required — Stand B', severity: 'medium', time: '32m ago' },
]

export default function OrganizerDashboard() {
  const [activeEvent, setActiveEvent] = useState(0)

  return (
    <PageLayout title="Organizer Dashboard" subtitle="Event management and operations control">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Tickets Sold', value: '94,000', change: '+2.3%', icon: Calendar, color: '#00e5a0' },
          { label: 'Revenue Today', value: '$1.45M', change: '+18%', icon: TrendingUp, color: '#0080ff' },
          { label: 'Staff On-Duty', value: '1,248', change: '98.2% present', icon: Users, color: '#f59e0b' },
          { label: 'Open Incidents', value: '3', change: '1 high severity', icon: AlertCircle, color: '#ef4444' },
        ].map(({ label, value, change, icon: Icon, color }) => (
          <div key={label} className="stat-card">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>{label.toUpperCase()}</span>
              <Icon size={16} style={{ color }} />
            </div>
            <div className="text-2xl font-black" style={{ color }}>{value}</div>
            <div className="text-xs mt-1" style={{ color: '#7a9cc0' }}>{change}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Revenue Chart */}
        <div className="card md:col-span-2">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Weekly Revenue & Tickets</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{ fontSize: 11, fill: '#7a9cc0' }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: '#7a9cc0' }} axisLine={false} tickLine={false} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 12 }} />
              <Line yAxisId="left" type="monotone" dataKey="revenue" stroke="#00e5a0" strokeWidth={2} dot={false} />
              <Line yAxisId="right" type="monotone" dataKey="tickets" stroke="#0080ff" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Capacity Pie */}
        <div className="card flex flex-col">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Stadium Capacity</h3>
          <div className="flex-1 flex flex-col items-center justify-center">
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie data={capacityData} cx="50%" cy="50%" innerRadius={45} outerRadius={65} dataKey="value" startAngle={90} endAngle={-270}>
                  {capacityData.map(({ color }, i) => <Cell key={i} fill={color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="text-center mt-2">
              <p className="text-2xl font-black glow-text" style={{ color: '#00e5a0' }}>94.9%</p>
              <p className="text-xs" style={{ color: '#7a9cc0' }}>Occupancy Rate</p>
            </div>
          </div>
        </div>
      </div>

      {/* Events */}
      <div className="card mb-6">
        <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Upcoming Events</h3>
        <div className="space-y-3">
          {EVENTS.map(({ name, date, status, tickets, capacity }, i) => {
            const pct = Math.round((tickets / capacity) * 100)
            const statusColor = status === 'live' ? '#00e5a0' : status === 'scheduled' ? '#0080ff' : '#7a9cc0'
            return (
              <div key={name} onClick={() => setActiveEvent(i)} className="p-3 rounded-xl cursor-pointer transition-colors" style={{ background: activeEvent === i ? 'rgba(0,229,160,0.07)' : 'rgba(255,255,255,0.03)' }}>
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <span className="font-semibold text-sm" style={{ color: '#e8f4ff' }}>{name}</span>
                    <span className="ml-2 text-xs" style={{ color: '#7a9cc0' }}><Clock size={11} className="inline mr-0.5" />{date}</span>
                  </div>
                  <span style={{ padding: '0.15rem 0.6rem', borderRadius: 999, fontSize: '0.7rem', fontWeight: 700, background: `${statusColor}20`, color: statusColor }}>{status.toUpperCase()}</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.1)' }}>
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: statusColor }} />
                  </div>
                  <span className="text-xs font-semibold" style={{ color: statusColor }}>{pct}%</span>
                  <span className="text-xs" style={{ color: '#7a9cc0' }}>{tickets.toLocaleString()} / {capacity.toLocaleString()}</span>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Incidents */}
      <div className="card">
        <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Active Incidents</h3>
        <div className="space-y-3">
          {INCIDENTS.map(({ id, desc, severity, time }) => {
            const color = severity === 'high' ? '#ef4444' : severity === 'medium' ? '#f59e0b' : '#7a9cc0'
            return (
              <div key={id} className="flex items-start gap-3 p-3 rounded-lg" style={{ background: 'rgba(255,255,255,0.03)' }}>
                <AlertCircle size={16} style={{ color, flexShrink: 0, marginTop: 1 }} />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold" style={{ color }}>{id}</span>
                    <span className="text-xs px-1.5 py-0.5 rounded font-semibold" style={{ background: `${color}20`, color }}>{severity}</span>
                  </div>
                  <p className="text-sm mt-0.5" style={{ color: '#e8f4ff' }}>{desc}</p>
                  <p className="text-xs mt-0.5" style={{ color: '#7a9cc0' }}>{time}</p>
                </div>
                <button className="btn-secondary text-xs" style={{ padding: '0.25rem 0.75rem' }}>Resolve</button>
              </div>
            )
          })}
        </div>
      </div>
    </PageLayout>
  )
}
