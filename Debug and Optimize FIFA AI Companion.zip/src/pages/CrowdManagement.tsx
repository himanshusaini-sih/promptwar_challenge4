import { useState } from 'react'
import { XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts'
import { Users, AlertTriangle, TrendingUp, Activity } from 'lucide-react'
import PageLayout from '../components/PageLayout'

const flowData = Array.from({ length: 10 }, (_, i) => ({
  time: `${10 + i}:00`,
  inflow: Math.round(3000 + Math.random() * 5000),
  outflow: Math.round(500 + Math.random() * 2000),
}))

const ZONES = [
  { name: 'Gate A – Main', density: 78, level: 'normal', count: 14200 },
  { name: 'Gate B – North', density: 94, level: 'high', count: 17000 },
  { name: 'Section 12', density: 89, level: 'high', count: 8900 },
  { name: 'Concourse Level 1', density: 67, level: 'moderate', count: 6700 },
  { name: 'VIP Zone', density: 82, level: 'normal', count: 4100 },
  { name: 'South Stand', density: 96, level: 'critical', count: 9600 },
]

export default function CrowdManagement() {
  const [view, setView] = useState<'realtime' | 'prediction'>('realtime')

  return (
    <PageLayout title="Crowd Management" subtitle="Real-time crowd density and flow monitoring">
      {/* Toggle */}
      <div className="flex gap-1 mb-8 p-1 rounded-xl w-fit" style={{ background: 'rgba(255,255,255,0.04)' }}>
        {(['realtime', 'prediction'] as const).map(v => (
          <button key={v} onClick={() => setView(v)}
            style={{
              padding: '0.4rem 1rem', borderRadius: '8px', fontSize: '0.8125rem', fontWeight: 600,
              border: 'none', cursor: 'pointer', textTransform: 'capitalize',
              background: view === v ? 'rgba(0,229,160,0.15)' : 'transparent',
              color: view === v ? '#00e5a0' : '#7a9cc0',
            }}>{v === 'realtime' ? 'Real-Time' : 'Prediction'}</button>
        ))}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Crowd', value: '89,241', icon: Users, color: '#00e5a0' },
          { label: 'Critical Zones', value: '1', icon: AlertTriangle, color: '#ef4444' },
          { label: 'High Zones', value: '2', icon: TrendingUp, color: '#f59e0b' },
          { label: 'Flow Rate', value: '+2,340/hr', icon: Activity, color: '#0080ff' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="stat-card flex items-center gap-3">
            <Icon size={20} style={{ color, flexShrink: 0 }} />
            <div>
              <div className="text-xl font-black" style={{ color }}>{value}</div>
              <div className="text-xs" style={{ color: '#7a9cc0' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Zone Density */}
        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Zone Density Levels</h3>
          <div className="space-y-3">
            {ZONES.map(({ name, density, level, count }) => {
              const color = level === 'critical' ? '#ef4444' : level === 'high' ? '#f59e0b' : level === 'moderate' ? '#0080ff' : '#00e5a0'
              return (
                <div key={name}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium" style={{ color: '#e8f4ff' }}>{name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs" style={{ color: '#7a9cc0' }}>{count.toLocaleString()}</span>
                      <span style={{ padding: '0.1rem 0.5rem', borderRadius: 999, fontSize: '0.65rem', fontWeight: 700, background: `${color}20`, color }}>{level}</span>
                    </div>
                  </div>
                  <div className="h-2 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <div style={{ width: `${density}%`, height: '100%', borderRadius: 9999, background: color, transition: 'width 0.5s' }} />
                  </div>
                  <div className="text-right text-xs mt-0.5" style={{ color }}>{density}%</div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Flow Chart */}
        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Crowd Flow (In/Out)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={flowData}>
              <defs>
                <linearGradient id="inGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00e5a0" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#00e5a0" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="outGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 11 }} />
              <Area type="monotone" dataKey="inflow" stroke="#00e5a0" strokeWidth={2} fill="url(#inGrad)" name="Inflow" />
              <Area type="monotone" dataKey="outflow" stroke="#ef4444" strokeWidth={2} fill="url(#outGrad)" name="Outflow" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Alerts */}
      <div className="card">
        <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Crowd Alerts & Recommendations</h3>
        <div className="space-y-3">
          {[
            { msg: 'South Stand approaching critical density (96%). Open overflow areas on Level 3.', color: '#ef4444' },
            { msg: 'Gate B queue exceeds 15 minutes. Redirect arriving fans to Gate D.', color: '#f59e0b' },
            { msg: 'Section 12 density normalizing. No action required.', color: '#00e5a0' },
          ].map(({ msg, color }) => (
            <div key={msg} className="flex items-start gap-3 p-3 rounded-lg" style={{ background: `${color}08`, border: `1px solid ${color}20` }}>
              <AlertTriangle size={14} style={{ color, flexShrink: 0, marginTop: 2 }} />
              <p className="text-sm" style={{ color: '#e8f4ff' }}>{msg}</p>
            </div>
          ))}
        </div>
      </div>
    </PageLayout>
  )
}
