import { useState } from 'react'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts'
import PageLayout from '../components/PageLayout'

const hourlyData = Array.from({ length: 12 }, (_, i) => ({
  hour: `${8 + i}:00`,
  attendance: Math.round(5000 + i * 8000 + Math.random() * 2000),
  transactions: Math.round(200 + i * 400 + Math.random() * 100),
  incidents: Math.round(Math.random() * 3),
}))

const zoneData = [
  { zone: 'North Stand', capacity: 18000, occupied: 17200, revenue: 182000 },
  { zone: 'South Stand', capacity: 22000, occupied: 19800, revenue: 210000 },
  { zone: 'East Stand', capacity: 20000, occupied: 18500, revenue: 196000 },
  { zone: 'West Stand', capacity: 20000, occupied: 19100, revenue: 201000 },
  { zone: 'VIP Zone', capacity: 5000, occupied: 4900, revenue: 490000 },
  { zone: 'Family Zone', capacity: 9000, occupied: 9741, revenue: 97000 },
]

const PERIODS = ['Today', 'This Week', 'This Month', 'Season']

export default function AnalyticsPage() {
  const [period, setPeriod] = useState('Today')

  return (
    <PageLayout title="Analytics" subtitle="Stadium performance intelligence and crowd insights">
      {/* Period Selector */}
      <div className="flex gap-1 mb-8 p-1 rounded-xl w-fit" style={{ background: 'rgba(255,255,255,0.04)' }}>
        {PERIODS.map(p => (
          <button key={p} onClick={() => setPeriod(p)}
            style={{
              padding: '0.4rem 1rem', borderRadius: '8px', fontSize: '0.8125rem', fontWeight: 600,
              border: 'none', cursor: 'pointer',
              background: period === p ? 'rgba(0,229,160,0.15)' : 'transparent',
              color: period === p ? '#00e5a0' : '#7a9cc0',
            }}>{p}</button>
        ))}
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Attendance', value: '89,241', delta: '+4.2%', positive: true },
          { label: 'Revenue', value: '$1.45M', delta: '+18.3%', positive: true },
          { label: 'Avg Queue Wait', value: '6.4 min', delta: '-2.1 min', positive: true },
          { label: 'Incidents Logged', value: '14', delta: '+2', positive: false },
        ].map(({ label, value, delta, positive }) => (
          <div key={label} className="stat-card">
            <div className="text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>{label.toUpperCase()}</div>
            <div className="text-2xl font-black" style={{ color: '#e8f4ff' }}>{value}</div>
            <div className="text-xs mt-1 font-semibold" style={{ color: positive ? '#00e5a0' : '#ef4444' }}>{delta}</div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Attendance Over Time</h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={hourlyData}>
              <defs>
                <linearGradient id="attGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00e5a0" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#00e5a0" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="hour" tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 11 }} />
              <Area type="monotone" dataKey="attendance" stroke="#00e5a0" strokeWidth={2} fill="url(#attGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Transactions & Incidents</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={hourlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="hour" tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 11 }} />
              <Legend wrapperStyle={{ fontSize: '11px', color: '#7a9cc0' }} />
              <Line yAxisId="left" type="monotone" dataKey="transactions" stroke="#0080ff" strokeWidth={2} dot={false} name="Transactions" />
              <Line yAxisId="right" type="monotone" dataKey="incidents" stroke="#ef4444" strokeWidth={2} dot={false} name="Incidents" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Zone Revenue */}
      <div className="card mb-6">
        <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Zone Occupancy & Revenue</h3>
        <div className="overflow-x-auto">
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(0,229,160,0.12)' }}>
                {['Zone', 'Capacity', 'Occupied', 'Occupancy %', 'Revenue'].map(h => (
                  <th key={h} style={{ padding: '0.5rem 0.75rem', textAlign: 'left', fontSize: '0.75rem', fontWeight: 600, color: '#7a9cc0', letterSpacing: '0.05em' }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {zoneData.map(({ zone, capacity, occupied, revenue }) => {
                const pct = Math.round((occupied / capacity) * 100)
                return (
                  <tr key={zone} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <td style={{ padding: '0.75rem', color: '#e8f4ff', fontSize: '0.875rem', fontWeight: 500 }}>{zone}</td>
                    <td style={{ padding: '0.75rem', color: '#7a9cc0', fontSize: '0.875rem' }}>{capacity.toLocaleString()}</td>
                    <td style={{ padding: '0.75rem', color: '#7a9cc0', fontSize: '0.875rem' }}>{occupied.toLocaleString()}</td>
                    <td style={{ padding: '0.75rem' }}>
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.1)' }}>
                          <div style={{ width: `${Math.min(pct, 100)}%`, height: '100%', borderRadius: 9999, background: pct > 95 ? '#ef4444' : '#00e5a0' }} />
                        </div>
                        <span style={{ fontSize: '0.75rem', fontWeight: 700, color: pct > 95 ? '#ef4444' : '#00e5a0' }}>{pct}%</span>
                      </div>
                    </td>
                    <td style={{ padding: '0.75rem', color: '#00e5a0', fontSize: '0.875rem', fontWeight: 600 }}>${revenue.toLocaleString()}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bar Chart */}
      <div className="card">
        <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Zone Revenue Comparison</h3>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={zoneData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="zone" tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: '#7a9cc0' }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
            <Tooltip contentStyle={{ background: '#0a1932', border: '1px solid rgba(0,229,160,0.3)', borderRadius: 8, color: '#e8f4ff', fontSize: 11 }} />
            <Bar dataKey="revenue" fill="#0080ff" radius={[4, 4, 0, 0]} name="Revenue" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </PageLayout>
  )
}
