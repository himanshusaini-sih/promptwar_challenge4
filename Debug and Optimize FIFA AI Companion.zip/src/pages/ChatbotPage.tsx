import { useState, useRef, useEffect } from 'react'
import { Send, Bot, User, RotateCcw } from 'lucide-react'
import PageLayout from '../components/PageLayout'

interface Message {
  id: number
  role: 'user' | 'assistant'
  content: string
  time: string
}

const QUICK_PROMPTS = [
  "What time does Gate B open?",
  "How do I get to the stadium?",
  "What's the current crowd situation?",
  "Where are the food stalls?",
  "Emergency procedures?",
]

const CANNED_RESPONSES: Record<string, string> = {
  default: "I'm your FIFA AI Stadium Companion. I can help with gate information, crowd updates, transportation, food services, emergency procedures, and more. What would you like to know?",
  gate: "**Gate B** (North Entrance) is currently open with a **~3 minute wait**. Gates A, C, D, and E are also operational. Gate B is your nearest entry for Blocks B and C. I recommend arriving at least 30 minutes before kick-off.",
  crowd: "Current stadium occupancy is **89,241 fans (94.9%)**. The highest crowd density is near Gate C and Section 12. Gate B currently has the shortest queue. VIP and premium zones are operating normally.",
  transport: "**Bus**: Lines 12, 34, and 56 stop directly at the stadium. Next bus in 8 minutes.\n**Metro**: Red Line — Stadium Station exit 2. Every 4 minutes.\n**Taxi/Rideshare**: Designated drop-off on West Road.\n**Car Park**: P3 and P4 have spaces available.",
  food: "**Food & Beverage Zones**:\n- Level 1: Concourse 1-A through 1-F (fast food, local cuisine)\n- Level 2: Restaurant Row (table service available)\n- Level 3: Premium Lounge (VIP ticket holders)\n\nYou can also order to your seat via the Fan Hub app!",
  emergency: "**Emergency Procedures**:\n1. **Medical**: Call 999 or find the nearest green First Aid kiosk\n2. **Fire**: Follow evacuation signs to nearest exit\n3. **Security**: Alert any steward (orange vest) or call Security Hotline: +974-500-SAFE\n4. **Lost Child**: Go to Family Support Center at Gate A\n\nAll exits are clearly marked. Please stay calm and follow steward instructions.",
}

function getResponse(input: string): string {
  const lower = input.toLowerCase()
  if (lower.includes('gate') || lower.includes('enter') || lower.includes('open')) return CANNED_RESPONSES.gate
  if (lower.includes('crowd') || lower.includes('busy') || lower.includes('people')) return CANNED_RESPONSES.crowd
  if (lower.includes('transport') || lower.includes('bus') || lower.includes('metro') || lower.includes('train') || lower.includes('get to')) return CANNED_RESPONSES.transport
  if (lower.includes('food') || lower.includes('eat') || lower.includes('drink') || lower.includes('restaurant')) return CANNED_RESPONSES.food
  if (lower.includes('emergency') || lower.includes('medical') || lower.includes('fire') || lower.includes('safe')) return CANNED_RESPONSES.emergency
  return "Thanks for your question! I'm checking the latest stadium data... Based on current conditions, I recommend contacting the nearest steward or checking the Fan Hub for real-time updates. Is there anything specific I can help you with?"
}

function now() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

export default function ChatbotPage() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, role: 'assistant', content: CANNED_RESPONSES.default, time: now() }
  ])
  const [input, setInput] = useState('')
  const [typing, setTyping] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, typing])

  const sendMessage = async (text: string) => {
    if (!text.trim() || typing) return
    const userMsg: Message = { id: Date.now(), role: 'user', content: text.trim(), time: now() }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setTyping(true)
    await new Promise(r => setTimeout(r, 800 + Math.random() * 600))
    const response = getResponse(text)
    setTyping(false)
    setMessages(prev => [...prev, { id: Date.now() + 1, role: 'assistant', content: response, time: now() }])
  }

  const reset = () => {
    setMessages([{ id: 1, role: 'assistant', content: CANNED_RESPONSES.default, time: now() }])
    setInput('')
  }

  const renderContent = (text: string) => {
    return text.split('\n').map((line, i) => {
      const bold = line.replace(/\*\*(.+?)\*\*/g, '<strong style="color:#00e5a0">$1</strong>')
      return <p key={i} dangerouslySetInnerHTML={{ __html: bold }} style={{ marginBottom: i < text.split('\n').length - 1 ? '0.25rem' : 0 }} />
    })
  }

  return (
    <PageLayout
      title="AI Stadium Assistant"
      subtitle="Powered by FIFA AI — ask anything about the match day"
      actions={
        <button onClick={reset} className="btn-secondary text-xs" style={{ padding: '0.375rem 0.875rem' }}>
          <RotateCcw size={13} /> New Chat
        </button>
      }
    >
      <div className="flex gap-6" style={{ height: 'calc(100vh - 180px)' }}>
        {/* Chat Area */}
        <div className="flex-1 flex flex-col card" style={{ padding: 0, overflow: 'hidden' }}>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map(({ id, role, content, time }) => (
              <div key={id} className={`flex gap-3 ${role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: role === 'assistant' ? 'rgba(0,229,160,0.15)' : 'rgba(0,128,255,0.15)', border: `1px solid ${role === 'assistant' ? 'rgba(0,229,160,0.3)' : 'rgba(0,128,255,0.3)'}` }}>
                  {role === 'assistant' ? <Bot size={14} style={{ color: '#00e5a0' }} /> : <User size={14} style={{ color: '#0080ff' }} />}
                </div>
                <div style={{ maxWidth: '75%' }}>
                  <div className="px-4 py-3 rounded-2xl text-sm"
                    style={{
                      background: role === 'assistant' ? 'rgba(10, 25, 50, 0.8)' : 'rgba(0, 128, 255, 0.15)',
                      border: `1px solid ${role === 'assistant' ? 'rgba(0,229,160,0.15)' : 'rgba(0,128,255,0.3)'}`,
                      color: '#e8f4ff',
                      lineHeight: 1.6,
                    }}>
                    {renderContent(content)}
                  </div>
                  <p className="text-xs mt-1 px-1" style={{ color: '#7a9cc0', textAlign: role === 'user' ? 'right' : 'left' }}>{time}</p>
                </div>
              </div>
            ))}

            {typing && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(0,229,160,0.15)', border: '1px solid rgba(0,229,160,0.3)' }}>
                  <Bot size={14} style={{ color: '#00e5a0' }} />
                </div>
                <div className="px-4 py-3 rounded-2xl" style={{ background: 'rgba(10, 25, 50, 0.8)', border: '1px solid rgba(0,229,160,0.15)' }}>
                  <div className="flex gap-1.5 items-center h-4">
                    <span className="typing-dot" />
                    <span className="typing-dot" />
                    <span className="typing-dot" />
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t" style={{ borderColor: 'rgba(0,229,160,0.12)' }}>
            <form onSubmit={e => { e.preventDefault(); sendMessage(input) }} className="flex gap-3">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder="Ask about gates, transport, food, emergency..."
                style={{
                  flex: 1,
                  padding: '0.625rem 1rem',
                  background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(0,229,160,0.2)',
                  borderRadius: '10px',
                  color: '#e8f4ff',
                  fontSize: '0.875rem',
                  outline: 'none',
                }}
                onFocus={e => (e.target.style.borderColor = '#00e5a0')}
                onBlur={e => (e.target.style.borderColor = 'rgba(0,229,160,0.2)')}
              />
              <button type="submit" disabled={!input.trim() || typing} className="btn-primary" style={{ padding: '0.625rem 1rem', opacity: !input.trim() || typing ? 0.5 : 1 }}>
                <Send size={16} />
              </button>
            </form>
          </div>
        </div>

        {/* Quick Prompts */}
        <div className="w-56 flex-shrink-0">
          <div className="card">
            <h3 className="text-xs font-bold mb-3" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>QUICK QUESTIONS</h3>
            <div className="space-y-2">
              {QUICK_PROMPTS.map(p => (
                <button key={p} onClick={() => sendMessage(p)}
                  className="w-full text-left text-xs p-2.5 rounded-lg transition-all"
                  style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(0,229,160,0.1)', color: '#7a9cc0', cursor: 'pointer' }}
                  onMouseEnter={e => { (e.target as HTMLElement).style.borderColor = 'rgba(0,229,160,0.35)'; (e.target as HTMLElement).style.color = '#00e5a0' }}
                  onMouseLeave={e => { (e.target as HTMLElement).style.borderColor = 'rgba(0,229,160,0.1)'; (e.target as HTMLElement).style.color = '#7a9cc0' }}
                >
                  {p}
                </button>
              ))}
            </div>

            <div className="mt-6">
              <h3 className="text-xs font-bold mb-3" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>STATUS</h3>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-xs" style={{ color: '#00e5a0' }}>AI Online</span>
              </div>
              <p className="text-xs mt-2" style={{ color: '#7a9cc0' }}>Response time: ~0.9s</p>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
