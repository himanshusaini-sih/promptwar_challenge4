import type { ReactNode } from 'react'

interface PageLayoutProps {
  title: string
  subtitle?: string
  children: ReactNode
  actions?: ReactNode
}

export default function PageLayout({ title, subtitle, children, actions }: PageLayoutProps) {
  return (
    <main
      className="min-h-screen"
      style={{
        paddingLeft: 'calc(220px + 1.5rem)',
        paddingRight: '1.5rem',
        paddingTop: '2rem',
        paddingBottom: '3rem',
        background: '#050d1a',
      }}
    >
      <div className="max-w-6xl mx-auto">
        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-2xl font-black" style={{ color: '#e8f4ff' }}>{title}</h1>
            {subtitle && <p className="text-sm mt-1" style={{ color: '#7a9cc0' }}>{subtitle}</p>}
          </div>
          {actions && <div className="flex items-center gap-3">{actions}</div>}
        </div>
        <div className="animate-fade-in">{children}</div>
      </div>
    </main>
  )
}
