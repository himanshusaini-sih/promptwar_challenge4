import { useState } from 'react'
import { CheckCircle2, Clock, MapPin, UserCircle, AlertCircle } from 'lucide-react'
import PageLayout from '../components/PageLayout'

const SHIFTS = [
  { id: 'S-001', role: 'Gate Marshal', zone: 'Gate B — North Entrance', time: '07:00 – 13:00', status: 'active', supervisor: 'Ahmed Al-Rashid' },
  { id: 'S-002', role: 'Crowd Control', zone: 'Section 12 – Lower Tier', time: '13:00 – 19:00', status: 'upcoming', supervisor: 'Maria Santos' },
  { id: 'S-003', role: 'Medical Support', zone: 'First Aid Station 3', time: '19:00 – 23:00', status: 'upcoming', supervisor: 'Dr. Liu Wei' },
]

const TASKS = [
  { id: 1, task: 'Check all gate barriers are operational', done: true },
  { id: 2, task: 'Brief incoming crowd on entry procedures', done: true },
  { id: 3, task: 'Report gate count to supervisor at 10:00', done: false },
  { id: 4, task: 'Monitor queue length every 15 minutes', done: false },
  { id: 5, task: 'Complete shift handover report', done: false },
]

const ANNOUNCEMENTS = [
  { title: 'New briefing materials available', time: '30 min ago', type: 'info' },
  { title: 'Emergency drill scheduled for 14:30', time: '1 hr ago', type: 'warning' },
  { title: 'Volunteer of the Month nominations open', time: '2 hrs ago', type: 'success' },
]

export default function VolunteerDashboard() {
  const [tasks, setTasks] = useState(TASKS)

  const toggleTask = (id: number) => {
    setTasks(t => t.map(task => task.id === id ? { ...task, done: !task.done } : task))
  }

  const completed = tasks.filter(t => t.done).length

  return (
    <PageLayout title="Volunteer Hub" subtitle="Your shift assignments and tasks for today">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Shifts Today', value: '3', color: '#00e5a0' },
          { label: 'Hours Volunteered', value: '12', color: '#0080ff' },
          { label: 'Tasks Complete', value: `${completed}/${tasks.length}`, color: '#f59e0b' },
          { label: 'Volunteer Score', value: '★ 4.9', color: '#8b5cf6' },
        ].map(({ label, value, color }) => (
          <div key={label} className="stat-card">
            <div className="text-xs font-semibold mb-2" style={{ color: '#7a9cc0', letterSpacing: '0.06em' }}>{label.toUpperCase()}</div>
            <div className="text-2xl font-black" style={{ color }}>{value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Shifts */}
        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Today's Shifts</h3>
          <div className="space-y-4">
            {SHIFTS.map(({ id, role, zone, time, status, supervisor }) => {
              const color = status === 'active' ? '#00e5a0' : '#7a9cc0'
              return (
                <div key={id} className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: `1px solid ${status === 'active' ? 'rgba(0,229,160,0.25)' : 'rgba(255,255,255,0.06)'}` }}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-sm" style={{ color: '#e8f4ff' }}>{role}</span>
                    <span style={{ padding: '0.15rem 0.6rem', borderRadius: 999, fontSize: '0.7rem', fontWeight: 700, background: `${color}20`, color }}>{status.toUpperCase()}</span>
                  </div>
                  <p className="text-xs" style={{ color: '#7a9cc0' }}><MapPin size={11} className="inline mr-1" />{zone}</p>
                  <p className="text-xs mt-1" style={{ color: '#7a9cc0' }}><Clock size={11} className="inline mr-1" />{time}</p>
                  <p className="text-xs mt-1" style={{ color: '#7a9cc0' }}><UserCircle size={11} className="inline mr-1" />Supervisor: {supervisor}</p>
                </div>
              )
            })}
          </div>
        </div>

        {/* Tasks */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-sm" style={{ color: '#e8f4ff' }}>Today's Tasks</h3>
            <span className="text-xs font-semibold" style={{ color: '#00e5a0' }}>{completed}/{tasks.length} done</span>
          </div>
          <div className="w-full h-1.5 rounded-full mb-4" style={{ background: 'rgba(255,255,255,0.1)' }}>
            <div className="h-full rounded-full transition-all" style={{ width: `${(completed / tasks.length) * 100}%`, background: '#00e5a0' }} />
          </div>
          <div className="space-y-2">
            {tasks.map(({ id, task, done }) => (
              <button key={id} onClick={() => toggleTask(id)} className="w-full flex items-center gap-3 p-2.5 rounded-lg text-left transition-colors" style={{ background: done ? 'rgba(0,229,160,0.05)' : 'rgba(255,255,255,0.03)' }}>
                <CheckCircle2 size={18} style={{ color: done ? '#00e5a0' : '#3a5070', flexShrink: 0 }} />
                <span className="text-sm" style={{ color: done ? '#7a9cc0' : '#e8f4ff', textDecoration: done ? 'line-through' : 'none' }}>{task}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Announcements */}
        <div className="card md:col-span-2">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Announcements</h3>
          <div className="space-y-3">
            {ANNOUNCEMENTS.map(({ title, time, type }) => {
              const color = type === 'success' ? '#00e5a0' : type === 'warning' ? '#f59e0b' : '#0080ff'
              return (
                <div key={title} className="flex items-center gap-3 p-3 rounded-lg" style={{ background: 'rgba(255,255,255,0.03)' }}>
                  <AlertCircle size={16} style={{ color, flexShrink: 0 }} />
                  <div className="flex-1">
                    <p className="text-sm font-medium" style={{ color: '#e8f4ff' }}>{title}</p>
                    <p className="text-xs" style={{ color: '#7a9cc0' }}>{time}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
