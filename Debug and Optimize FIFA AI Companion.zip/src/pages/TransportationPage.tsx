import { Bus, Train, MapPin, Clock, ArrowRight } from 'lucide-react'
import PageLayout from '../components/PageLayout'

const ROUTES = [
  { type: 'metro', icon: Train, name: 'Red Line – Stadium Station', eta: '4 min', status: 'on-time', frequency: 'Every 4 min', capacity: 85 },
  { type: 'bus', icon: Bus, name: 'Bus 12 – Stadium Express', eta: '8 min', status: 'on-time', frequency: 'Every 12 min', capacity: 62 },
  { type: 'bus', icon: Bus, name: 'Bus 34 – City Center', eta: '15 min', status: 'delayed', frequency: 'Every 20 min', capacity: 45 },
  { type: 'metro', icon: Train, name: 'Blue Line – West Junction', eta: '7 min', status: 'on-time', frequency: 'Every 6 min', capacity: 70 },
]

const PARKING = [
  { name: 'Car Park P1 – North', total: 2000, occupied: 1960, dist: '200m', status: 'full' },
  { name: 'Car Park P2 – East', total: 2500, occupied: 2200, dist: '350m', status: 'limited' },
  { name: 'Car Park P3 – South', total: 3000, occupied: 2100, dist: '500m', status: 'available' },
  { name: 'Car Park P4 – West', total: 1500, occupied: 950, dist: '450m', status: 'available' },
]

export default function TransportationPage() {
  return (
    <PageLayout title="Transportation Hub" subtitle="Real-time transport information and route planning">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Active Routes', value: '18', color: '#00e5a0' },
          { label: 'Park & Ride', value: '4 lots', color: '#0080ff' },
          { label: 'Avg Travel Time', value: '22 min', color: '#f59e0b' },
          { label: 'Shuttle Buses', value: '12 active', color: '#8b5cf6' },
        ].map(({ label, value, color }) => (
          <div key={label} className="stat-card">
            <div className="text-xs font-semibold mb-1" style={{ color: '#7a9cc0' }}>{label.toUpperCase()}</div>
            <div className="text-2xl font-black" style={{ color }}>{value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Live Routes */}
        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Live Transit Routes</h3>
          <div className="space-y-3">
            {ROUTES.map(({ icon: Icon, name, eta, status, frequency, capacity }) => {
              const statusColor = status === 'on-time' ? '#00e5a0' : '#f59e0b'
              const capColor = capacity > 80 ? '#ef4444' : capacity > 60 ? '#f59e0b' : '#00e5a0'
              return (
                <div key={name} className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'rgba(0,128,255,0.15)', border: '1px solid rgba(0,128,255,0.3)' }}>
                      <Icon size={16} style={{ color: '#0080ff' }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate" style={{ color: '#e8f4ff' }}>{name}</p>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-xs" style={{ color: '#7a9cc0' }}><Clock size={10} className="inline mr-0.5" />{frequency}</span>
                        <span className="text-xs font-semibold" style={{ color: statusColor }}>{status}</span>
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-sm font-bold" style={{ color: '#00e5a0' }}>{eta}</p>
                      <p className="text-xs" style={{ color: capColor }}>{capacity}% full</p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Parking */}
        <div className="card">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Parking Availability</h3>
          <div className="space-y-4">
            {PARKING.map(({ name, total, occupied, dist, status }) => {
              const pct = Math.round((occupied / total) * 100)
              const color = status === 'full' ? '#ef4444' : status === 'limited' ? '#f59e0b' : '#00e5a0'
              const available = total - occupied
              return (
                <div key={name}>
                  <div className="flex items-center justify-between mb-1.5">
                    <div>
                      <span className="text-sm font-medium" style={{ color: '#e8f4ff' }}>{name}</span>
                      <span className="ml-2 text-xs" style={{ color: '#7a9cc0' }}><MapPin size={10} className="inline" />{dist}</span>
                    </div>
                    <span style={{ padding: '0.1rem 0.5rem', borderRadius: 999, fontSize: '0.7rem', fontWeight: 700, background: `${color}20`, color }}>{status}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 rounded-full" style={{ background: 'rgba(255,255,255,0.08)' }}>
                      <div style={{ width: `${pct}%`, height: '100%', borderRadius: 9999, background: color }} />
                    </div>
                    <span className="text-xs w-16 text-right" style={{ color: '#7a9cc0' }}>{available.toLocaleString()} free</span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Journey Planner */}
        <div className="card md:col-span-2">
          <h3 className="font-bold text-sm mb-4" style={{ color: '#e8f4ff' }}>Journey Planner</h3>
          <div className="flex gap-3 items-end flex-wrap">
            <div className="flex-1 min-w-48">
              <label className="block text-xs font-semibold mb-1" style={{ color: '#7a9cc0' }}>FROM</label>
              <input defaultValue="City Center Hotel" style={{ width: '100%', padding: '0.625rem 0.875rem', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(0,229,160,0.2)', borderRadius: '8px', color: '#e8f4ff', fontSize: '0.875rem', outline: 'none' }} />
            </div>
            <ArrowRight size={20} style={{ color: '#7a9cc0', flexShrink: 0, marginBottom: '0.375rem' }} />
            <div className="flex-1 min-w-48">
              <label className="block text-xs font-semibold mb-1" style={{ color: '#7a9cc0' }}>TO</label>
              <input defaultValue="Lusail Stadium – Gate B" style={{ width: '100%', padding: '0.625rem 0.875rem', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(0,229,160,0.2)', borderRadius: '8px', color: '#e8f4ff', fontSize: '0.875rem', outline: 'none' }} />
            </div>
            <button className="btn-primary" style={{ flexShrink: 0 }}>Get Directions</button>
          </div>

          <div className="mt-4 p-4 rounded-xl" style={{ background: 'rgba(0,229,160,0.06)', border: '1px solid rgba(0,229,160,0.2)' }}>
            <p className="text-xs font-bold mb-3" style={{ color: '#00e5a0' }}>RECOMMENDED ROUTE</p>
            <div className="flex items-center gap-3 flex-wrap">
              {['City Hotel', 'Walk 5 min', 'Metro Station', 'Red Line (4 stops)', 'Stadium Station', 'Walk 3 min', 'Gate B'].map((step, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-sm" style={{ color: i % 2 === 0 ? '#e8f4ff' : '#7a9cc0', fontSize: i % 2 === 1 ? '0.75rem' : undefined }}>{step}</span>
                  {i < 6 && <ArrowRight size={12} style={{ color: '#7a9cc0' }} />}
                </div>
              ))}
            </div>
            <p className="text-xs mt-3" style={{ color: '#7a9cc0' }}>Total journey: ~22 minutes · Recommended departure: 18:20</p>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
