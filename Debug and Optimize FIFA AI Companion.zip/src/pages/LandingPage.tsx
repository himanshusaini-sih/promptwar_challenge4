import { useNavigate } from 'react-router-dom'
import { ArrowRight, Zap, Shield, BarChart3, Users, MessageSquare, Truck } from 'lucide-react'

const FEATURES = [
  { icon: Zap, title: 'AI-Powered Insights', desc: 'Real-time crowd intelligence and predictive analytics for smarter stadium management.' },
  { icon: Shield, title: 'Safety First', desc: 'Emergency response center and crowd management tools to keep every fan safe.' },
  { icon: BarChart3, title: 'Live Analytics', desc: 'Comprehensive dashboards tracking attendance, queues, and stadium performance.' },
  { icon: Users, title: 'Multi-Role Platform', desc: 'Tailored experiences for fans, organizers, volunteers, and staff.' },
  { icon: MessageSquare, title: 'AI Chat Assistant', desc: 'Intelligent chatbot answering questions about the stadium, schedule, and more.' },
  { icon: Truck, title: 'Transport Hub', desc: 'Integrated transportation planning with real-time traffic and route optimization.' },
]

const ROLES = [
  { label: 'Fan Hub', path: '/fan', color: '#00e5a0', desc: 'Discover matches, seats, and stadium services' },
  { label: 'Organizer', path: '/organizer', color: '#0080ff', desc: 'Manage events, capacity, and operations' },
  { label: 'Volunteer', path: '/volunteer', color: '#f59e0b', desc: 'View assignments, shifts, and zone maps' },
  { label: 'Staff', path: '/staff', color: '#8b5cf6', desc: 'Monitor crowd, security, and incidents' },
]

export default function LandingPage() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen grid-bg" style={{ background: '#050d1a' }}>
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-dark">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00e5a0, #0080ff)' }}>
              <span className="text-sm">⚽</span>
            </div>
            <span className="font-bold" style={{ color: '#00e5a0' }}>FIFA AI Stadium</span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/login')} className="btn-secondary" style={{ padding: '0.4rem 1rem', fontSize: '0.875rem' }}>Sign In</button>
            <button onClick={() => navigate('/signup')} className="btn-primary" style={{ padding: '0.4rem 1rem', fontSize: '0.875rem' }}>Get Started</button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="pt-32 pb-20 px-6 text-center relative overflow-hidden">
        {/* Glow orbs */}
        <div className="absolute top-20 left-1/4 w-96 h-96 rounded-full opacity-10 pointer-events-none" style={{ background: 'radial-gradient(circle, #00e5a0, transparent)', filter: 'blur(80px)' }} />
        <div className="absolute top-20 right-1/4 w-96 h-96 rounded-full opacity-10 pointer-events-none" style={{ background: 'radial-gradient(circle, #0080ff, transparent)', filter: 'blur(80px)' }} />

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6 text-xs font-semibold" style={{ background: 'rgba(0,229,160,0.1)', border: '1px solid rgba(0,229,160,0.3)', color: '#00e5a0' }}>
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          FIFA World Cup 2026 — Live Platform
        </div>

        <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight" style={{ color: '#e8f4ff' }}>
          The Smartest<br />
          <span className="gradient-text">Stadium Experience</span><br />
          Ever Built
        </h1>
        <p className="text-lg max-w-2xl mx-auto mb-10" style={{ color: '#7a9cc0' }}>
          AI-powered companion for fans, organizers, and staff. Real-time insights, crowd intelligence, and seamless stadium management — all in one platform.
        </p>

        <div className="flex flex-wrap gap-4 justify-center">
          <button onClick={() => navigate('/fan')} className="btn-primary" style={{ fontSize: '1rem', padding: '0.75rem 2rem' }}>
            Enter as Fan <ArrowRight size={18} />
          </button>
          <button onClick={() => navigate('/organizer')} className="btn-secondary" style={{ fontSize: '1rem', padding: '0.75rem 2rem' }}>
            Organizer Portal
          </button>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap justify-center gap-8 mt-16">
          {[['94,000+', 'Capacity'], ['120+', 'Staff Managed'], ['< 2min', 'Queue Prediction'], ['99.9%', 'Uptime']].map(([val, label]) => (
            <div key={label} className="text-center">
              <div className="text-3xl font-black glow-text" style={{ color: '#00e5a0' }}>{val}</div>
              <div className="text-xs mt-1" style={{ color: '#7a9cc0' }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Role Cards */}
      <section className="py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-10" style={{ color: '#e8f4ff' }}>Choose Your Role</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {ROLES.map(({ label, path, color, desc }) => (
              <button
                key={path}
                onClick={() => navigate(path)}
                className="card text-left p-4 transition-all"
                style={{ cursor: 'pointer', background: 'rgba(10, 25, 50, 0.6)' }}
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: `${color}20`, border: `1px solid ${color}40` }}>
                  <span style={{ color, fontSize: '18px' }}>●</span>
                </div>
                <div className="font-bold text-sm mb-1" style={{ color: '#e8f4ff' }}>{label}</div>
                <div className="text-xs" style={{ color: '#7a9cc0' }}>{desc}</div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-10" style={{ color: '#e8f4ff' }}>Platform Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="card p-6">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4" style={{ background: 'rgba(0,229,160,0.1)', border: '1px solid rgba(0,229,160,0.25)' }}>
                  <Icon size={20} style={{ color: '#00e5a0' }} />
                </div>
                <h3 className="font-bold mb-2" style={{ color: '#e8f4ff' }}>{title}</h3>
                <p className="text-sm" style={{ color: '#7a9cc0' }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 text-center border-t" style={{ borderColor: 'rgba(0,229,160,0.1)' }}>
        <p className="text-xs" style={{ color: '#7a9cc0' }}>© 2026 FIFA AI Stadium Companion — Powered by Advanced AI</p>
      </footer>
    </div>
  )
}
